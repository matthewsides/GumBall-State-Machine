// ConsoleApplication1.cpp : Defines the entry point for the console application.
//


#include "stdafx.h"
#include <iostream>
#include <windows.h>

// ^ External Libarys; iostream (provides basic input and output services) & stdafx.h (describes both standard system and project specific include files used frequently but change infrequently)
// ^ windows.h (contains declarations for all of the functions in the Windows API,Which defines a very large number of Windows specific functions)

#pragma comment(lib, "Winmm.lib")
// ^ A compiler that places a comment in the object or exe file, which can then be read by a linker.
// ^ (lib, "libname") tells the linker to add the 'libname' library to the list of library dependencies.
// ^ The linker is a program that makes executable files. The linker resolves linkage issues, meaning to resolve references to undefined symbols by finding out which other object defines a symbol in question, and replacing placeholders with the symbol's address
// ^ Linkage refers to the way in which a program is built out of a number of translation units (a translation unit is the ultimate input to a C or C++ compiler from which an object file is generated).


const int NO_COIN = 0;
const int HAS_COIN = 1;
const int TURN_CRANK = 2;
const int DISPENSE_GUM = 3;
// ^ List of states:
// ^ int is a whole number, const is a global or static variable that creates a read-only reference to a value (cannot be re-assigned or altered during run-time).
// ^ Block of code declares the variables as a const and type int along with the pre-defined value being stored within.

	class gumballMachine {
// ^ Class defined or data structure declared with keyword being gumballMachine, reference requirements for reason behind name. 
// ^ Class ensnares data and functions as its members, access is governed by the three access specifiers private, protected or public seen below.

	public:
// ^ Public is a class modifer which allows class members and functions to be used from outside of a class by any function or other classes. 

		int getState() {
			return state;
// ^ return statement stops execution and returns to the calling function.
// ^ In this instance information about the current state is returned and stored in the variable getState which is used in this program to display the current state, illustrated by numbers.
		}

		int gumBalls = 100;
		int Win = 0;
		// ^ int as alliterated in the above comments a whole number, the above code segment creates two variables defining the type, name and value of both.
		// ^ Theses variables are referenced and used later in the code/program. 
		void insertCoin() {
			if (state == NO_COIN) {
				std::cout << "Coin inserted\n";
				setState(HAS_COIN);
			} else {
				std::cout << "Coin could not be Inserted\n";
			}

		}

		void ejectCoin() {
			if (state == HAS_COIN) {
				std::cout << "Coin Ejected\n";
				setState(NO_COIN);
			} else {
				std::cout << "No Coin to eject\n";
			}
		}

		void turnCrank() {
			if (state == HAS_COIN) {
				std::cout << "Crank Turned\n";
				setState(TURN_CRANK);
			} else {
				std::cout << "No coin found\n";
				setState(HAS_COIN);
			}
		}
			
		void gumDispense() {
			if (state == TURN_CRANK) {
				std::cout << "GumBall Dispensed\n";
				Win = Win + 1;
				gumBalls = gumBalls - 1;
				std::cout << "GumBalls Left:"<< gumBalls<<"\n";
				setState(NO_COIN);
			}else { 
				std::cout << "Have you even tried turning the crank...\n"; 
				setState(TURN_CRANK);
			}
			if (Win >= 10) {
				PlaySound(TEXT("wins.wav"), NULL, SND_FILENAME| SND_ASYNC);
				//PlaySound(L"wins.wav", NULL, SND_FILENAME | SND_NODEFAULT | SND_ASYNC);
				std::cout << "Congratulations\n";
				gumBalls = gumBalls - 2;
				Win = 0;
				std::cout << "GumBalls Left:" << gumBalls << "\n";
			}
			if (gumBalls <= 0) {
				std::cout << "Out of balls... Ejecting\n";
				setState(NO_COIN);
				std::cout << "Refilling gummy goodness... patience is appreciated human\n";
				gumBalls = gumBalls + 100;

			}
// ^ Above code segments are seperated into functions that are all labeled and set as void, meaning that they do not return a value or takes no parameters.
// ^ Multiple If & else statements are used within the program to check the current state, if the state the machine is not in the correct state it will pass and execute the code stored under the else statement.
// ^ If the machine is in the correct state it will pass and execute the code under the If statement (within the brackets: {}).
// ^ The following also applies to the other If and else statements, however the equation or what is fundementally required to match is different.
// ^ Requirements to be met not relating to the state of the machine but rather a comparision between a variable and numbers to see whether it is greater or lesser than and equal to the pre-defined number.
// ^ Making a decision based on whether the requirements have been met.	
// ^ cout an abbreviation for console out (used to output string stored between "") (\n states that the string should be put on a new line ensuring that all the striong is not cluttered and printed on the same line).
// ^ Setstate changes the state of the machine which is identified by a number stored within a predefined varaible, which can be seen on lines 19-22 unless the code has been altered.
		}
			

	protected:
// ^ Protected (not in use currently) class members and functions can be used inside its class. Protected members and functions cannot be accessed from other classes directly and must be a friend function or be a class derived from this class (can be accessed when a class inherits this class). 

	private:
// ^ Privateclass members and functions can be used only inside of the class and by friend functions and classes.
		int state = 0;
		void setState(int newState) {
			state = newState;
// Code block creates new function that returns no value (Void) and declares 'new state' as an int which is stored within the variable 'state'.
		}

	

	};


int main()
// ^ main() function is the entry point of any C++ program. Execution of program is started in main.
{
		//using namespace std;
		//int cycleRe = 1;
		//int i;
		gumballMachine gumball;
// ^ references class gumballMachine and inserts into the main and gumball.
		//while (cycleRe >= 0) {
			std::cout << "Welcome to the Gumball State Machine!\n";
			std::cout << "Current State:" << gumball.getState() << "\n";
			//std::cout << "Please decide an action" << "\n";
			//cin >> i;
			
			gumball.insertCoin();
			gumball.insertCoin();
			gumball.ejectCoin();
			gumball.ejectCoin();
			gumball.insertCoin();
			gumball.turnCrank();
			gumball.gumDispense();
			//gumball.gumDispense();

			gumball.insertCoin();
			gumball.turnCrank();
			gumball.gumDispense();

			gumball.insertCoin();
			gumball.turnCrank();
			gumball.gumDispense();

			gumball.insertCoin();
			gumball.turnCrank();
			gumball.gumDispense();

			gumball.insertCoin();
			gumball.turnCrank();
			gumball.gumDispense();

			gumball.insertCoin();
			gumball.turnCrank();
			gumball.gumDispense();

			gumball.insertCoin();
			gumball.turnCrank();
			gumball.gumDispense();

			gumball.insertCoin();
			gumball.turnCrank();
			gumball.gumDispense();

			gumball.insertCoin();
			gumball.turnCrank();
			gumball.gumDispense();

			gumball.insertCoin();
			gumball.turnCrank();
			gumball.gumDispense();
// ^ Reference to the pre-defined functions,calls functions, initialises and executes said functions stored in/under the class gumballmachine which is defined as gumball in the main.

			
		//}

// Notes: 
// Use console and Microsofts Visual Studios Local Windows Debugger tool to run and test (Exe currently broken as program closes upon attempting to open, will be fixed in prior updates).
// -Always clean,compress,review,update and ensure the code is the most effienct, using the least amount of lines it can!
// -Defined coding standards.
// -Shorten comments later please.
// -Change Program Names
// -Fix Loop.
// -Fix Sound.
// -Add more sounds? Adds diversity.
// -Add way to access and give commands through console rather than manual input before build.
// -Include time libary and utilise time function to slow down rate inwhich text displays.
// -Possibly add colours to the gumballs to add more substance to the program.
// -Preferably add variable that stores gumballs taken & which the user now owns.
// -Future update possibility give user set amount of coins.
// -After coloured gumballs implementation add randomness factor where once the machine refills its balls the amount of each colour is changed each time.
// -Last but not least have fun with it! :)
	
// Original Dev: Matthew Sides
// -Use of the full code is granted as long as I am credited or contacted prior, use of code snippets is allowed without the requirement to credit or contact me.
// -Comments are provided for help with understanding the code along with suggestions for improvements that may be implemented in future updates/builds. Otherwise enjoy the program!


	return 0;
// ^ Red Circle is a breakpoint in where the programs halts execution (A MVS tool).
// ^ This can be altered and also may not disappear, in the event of the circle not appearing set a new break point in the same position (line 211).
}

